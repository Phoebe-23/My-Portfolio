## Usage

This project was bootstrapped with [Vite](https://vitejs.dev/).

### Project setup

```
npm install
```

npm install react-router-dom mysql mysql2 express axios

#### Compiles and hot-reloads for development

```
npm run dev
```

#### Compiles and minifies for production

```
npm run build
```

#### Customize configuration

See [Configuration Reference](https://vitejs.dev/guide/).
